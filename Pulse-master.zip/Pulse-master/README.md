**Pulse**

This program can attempt unlimited amount of passwords on both Instagram & Twitter, without getting locked
